# Recurrent Neural Networks (RNNs): Intuition, Mathematics, and Worked Flow

> **Learning goal:** Understand why RNNs are useful for sequences, what their hidden state represents, how the recurrent weight matrices work, how words become vectors, and how a vanilla RNN can predict the next word.

This guide follows the concepts and framing of the supplied article, **“The Intuition Behind Recurrent Neural Networks” by Serban Liviu**. The diagrams in this folder are original explanatory diagrams made for this guide. Numerical values explicitly described as illustrative are examples, not values reported by the article.

---

## Table of contents

1. [Why do we need RNNs?](#1-why-do-we-need-rnns)
2. [What is an RNN?](#2-what-is-an-rnn)
3. [The hidden state: recurrent memory](#3-the-hidden-state-recurrent-memory)
4. [The three weight matrices](#4-the-three-weight-matrices)
5. [The vanilla RNN equations](#5-the-vanilla-rnn-equations)
6. [One-hot encoding and word embeddings](#6-one-hot-encoding-and-word-embeddings)
7. [How vocabulary and embedding weights are initialized before training](#7-how-vocabulary-and-embedding-weights-are-initialized-before-training)
8. [Worked conceptual example: “Emperor has no”](#8-worked-conceptual-example-emperor-has-no)
9. [How the output layer and Softmax predict a word](#9-how-the-output-layer-and-softmax-predict-a-word)
10. [Sequence representations and sentence vectors](#10-sequence-representations-and-sentence-vectors)
11. [Stacked RNNs](#11-stacked-rnns)
12. [Three input-output patterns](#12-three-input-output-patterns)
13. [Sentiment analysis with an RNN](#13-sentiment-analysis-with-an-rnn)
14. [Limitations of vanilla RNNs](#14-limitations-of-vanilla-rnns)
15. [Key takeaways](#15-key-takeaways)
16. [Knowledge check](#16-knowledge-check)
17. [Glossary](#17-glossary)

---

## 1. Why do we need RNNs?

A traditional feedforward neural network is naturally suited to inputs with a fixed shape. For example, a 28 × 28 grayscale image can be flattened into a vector of 784 values. Every image passed to that particular network has the same input dimension.

Text is different. One sentence may contain three words and another may contain thirty. More importantly, **word order matters**.

Compare:

- “The movie was good.”
- “The movie was not good.”

A system that only counts the occurrence of the word `good` can miss the effect of `not`. The interpretation of a word can depend on earlier words.

An RNN is designed to process a sequence one element at a time while carrying forward a learned representation of what it has processed so far.

### Human-reading intuition

Imagine reading:

> The movie was not good.

Your interpretation develops as you read:

- `The`: little context so far.
- `movie`: you know the topic.
- `was`: you have more grammatical context.
- `not`: this changes the expected meaning of what follows.
- `good`: you interpret this word in the context of `not`.

An RNN attempts to model this kind of sequential dependency using numerical operations. It does not understand language exactly as a human does; it learns statistical representations useful for its training objective.

### Why a fixed-size feedforward input is awkward for text

A standard dense network expects a fixed-size vector. One could pad or truncate sentences, but that is a preprocessing workaround and does not itself provide a recurrent mechanism for carrying context from one word to the next.

RNNs provide a shared computation that can be repeated for sequences of different lengths.

---

## 2. What is an RNN?

A **Recurrent Neural Network (RNN)** is a neural network architecture for sequential data. Its defining feature is a recurrent connection: the computation at the current timestep receives information from the previous hidden state.

The main symbols are:

| Symbol | Meaning |
|---|---|
| \(x_t\) | Input at timestep \(t\) |
| \(h_t\) | Hidden state at timestep \(t\) |
| \(h_{t-1}\) | Hidden state from the previous timestep |
| \(y_t\) | Output at timestep \(t\) |
| \(W_{xh}\) | Input-to-hidden weight matrix |
| \(W_{hh}\) | Hidden-to-hidden (recurrent) weight matrix |
| \(W_{hy}\) | Hidden-to-output weight matrix |
| \(b_h, b_y\) | Bias vectors |
| \(f\) | Hidden-state activation function, often `tanh` in a vanilla RNN |

![Vanilla RNN cell: current input and previous hidden state are combined to produce the new hidden state.](images/rnn_cell.png)

The same recurrent cell is used at every timestep. Its parameters are shared across the sequence.

### The notebook analogy

Think of the hidden state as a notebook:

1. Read the first word and write a compact representation in the notebook.
2. Read the second word, consult the existing notes, and update them.
3. Read the third word and update the notes again.

The notebook is not a literal storage of every previous word. It is a fixed-size learned representation. Some information may be preserved, transformed, or lost.

---

## 3. The hidden state: recurrent memory

Consider the sequence:

> I → love → AI

For a simple example, suppose the hidden state has three components:

\[
h_0 = \begin{bmatrix}0\\0\\0\end{bmatrix}
\]

A common simple initialization is a zero vector. This means there is no previous sequence information at the beginning.

### Timestep 1: input “I”

The network processes the first input and creates a hidden state:

\[
h_1=f(W_{xh}x_1+W_{hh}h_0+b_h)
\]

Since \(h_0=0\), the recurrent contribution is zero (assuming no other initial-state mechanism):

\[
h_1=f(W_{xh}x_1+b_h)
\]

The new state contains information derived from the first input.

### Timestep 2: input “love”

The next state uses both the new input and the previous state:

\[
h_2=f(W_{xh}x_2+W_{hh}h_1+b_h)
\]

The current word contributes through \(W_{xh}x_2\). The previous memory contributes through \(W_{hh}h_1\).

### Timestep 3: input “AI”

\[
h_3=f(W_{xh}x_3+W_{hh}h_2+b_h)
\]

Now the state has processed all three inputs.

![An RNN unrolled through three timesteps.](images/rnn_unrolled.png)

**Important distinction:** \(h_t\) is not simply a copy of the previous word or a perfect record of the entire sequence. It is a learned, fixed-width state that summarizes information useful to the model.

---

## 4. The three weight matrices

A vanilla RNN uses three main transformations.

### 4.1 \(W_{xh}\): input-to-hidden weights

This matrix transforms the current input representation into the hidden-state space:

\[
W_{xh}x_t
\]

Intuition: “What features of the current input should contribute to my updated state?”

### 4.2 \(W_{hh}\): hidden-to-hidden weights

This matrix transforms the previous hidden state:

\[
W_{hh}h_{t-1}
\]

Intuition: “How should information from my previous state be transformed before I combine it with the current input?”

This is the recurrent transformation that makes the network recurrent.

### 4.3 \(W_{hy}\): hidden-to-output weights

This matrix maps the current hidden state to output scores:

\[
o_t=W_{hy}h_t+b_y
\]

Intuition: “Given the state I have reached, what output should I produce?”

For next-word prediction, the output scores correspond to vocabulary entries. For sentiment classification, they can correspond to classes such as positive and negative.

### At a glance

| Matrix | Transformation | Role |
|---|---|---|
| \(W_{xh}\) | Current input → hidden space | Incorporates the current input |
| \(W_{hh}\) | Previous hidden state → hidden space | Carries transformed prior information |
| \(W_{hy}\) | Current hidden state → output space | Produces output scores |

These are learned parameters. Training adjusts them to reduce the model's prediction error.

---

## 5. The vanilla RNN equations

The hidden-state update is commonly written as:

\[
\boxed{h_t=\tanh(W_{xh}x_t+W_{hh}h_{t-1}+b_h)}
\]

The output logits are:

\[
\boxed{o_t=W_{hy}h_t+b_y}
\]

If the task is classification over a set of classes or vocabulary items, Softmax can convert the logits into probabilities:

\[
P(y_t=i)=\frac{e^{o_{t,i}}}{\sum_j e^{o_{t,j}}}
\]

### What does `tanh` do?

The hyperbolic tangent function applies element by element. Its output lies between \(-1\) and \(+1\).

For example:

\[
z=[3,-4,2]
\]

\[
\tanh(z)\approx[0.995,-0.999,0.964]
\]

![The tanh activation function.](images/tanh_curve.png)

Why use a nonlinear activation?

- It introduces nonlinearity into the state update.
- It bounds each hidden-state component between -1 and +1.
- It allows the network to learn more than a sequence of purely linear transformations.

The article uses `tanh` in its illustrative vanilla RNN explanation. Other activation choices exist, but `tanh` is a common textbook formulation.

---

## 6. One-hot encoding and word embeddings

A neural network needs numerical input. A word such as `Emperor` must first be represented numerically.

### 6.1 One-hot encoding

Suppose a tiny vocabulary has eight words:

| Word | Index |
|---|---:|
| King | 1 |
| Queen | 2 |
| Man | 3 |
| Woman | 4 |
| Emperor | 5 |
| Clothes | 6 |
| Has | 7 |
| No | 8 |

The one-hot vector for `Emperor` is:

\[
x_{\text{Emperor}}=
\begin{bmatrix}
0\\0\\0\\0\\1\\0\\0\\0
\end{bmatrix}
\]

Only the position corresponding to the word is 1. Every other position is 0.

One-hot encoding identifies a word, but it does not itself express semantic similarity. The one-hot vectors for `King` and `Queen` are different basis vectors and do not encode that these words are related.

### 6.2 Dense word embeddings

A word embedding represents a word as a dense, lower-dimensional vector.

For example, using three dimensions purely for illustration:

\[
e_{\text{king}}=
\begin{bmatrix}0.8\\0.3\\0.5\end{bmatrix},
\qquad
e_{\text{queen}}=
\begin{bmatrix}0.75\\0.35\\0.52\end{bmatrix}
\]

These illustrative vectors are close to each other. In a trained embedding space, words that occur in similar contexts can acquire related representations.

Real embeddings often have tens, hundreds, or thousands of dimensions; they cannot be visualized directly in ordinary 2D space.

### 6.3 How does an embedding lookup work?

Let:

- Vocabulary size \(V=8\).
- Embedding dimension \(d=3\).
- Embedding matrix \(E\in\mathbb{R}^{3\times8}\).

Each column of \(E\) is one word's embedding.

Multiplying a one-hot vector by \(E\) selects the corresponding column:

\[
e_{\text{Emperor}}=Ex_{\text{Emperor}}
\]

![A one-hot vector selects one column from an embedding matrix.](images/embedding_lookup.png)

In practical deep-learning frameworks, an embedding layer generally performs an indexed lookup rather than constructing a full one-hot vector and multiplying it by the entire matrix.

### 6.4 How are embeddings learned?

An embedding matrix can be trained along with the RNN.

For a next-word prediction task, training examples might include:

| Context/input | Target |
|---|---|
| King has no | Clothes |
| Queen has a | Crown |
| The sky is | Blue |
| I love | AI |

The model predicts a target word, computes a loss, and updates trainable parameters—including embeddings—through backpropagation.

The article also discusses pretrained Word2Vec embeddings. A pretrained embedding may be useful, but its learned representations depend on the corpus and training objective. Learning embeddings on the target corpus is another option.

### 6.5 Word2Vec analogy

The article mentions the well-known illustrative relationship:

\[
\text{king}-\text{man}+\text{woman}\approx\text{queen}
\]

This is an observed property of some learned embedding spaces, not a universal mathematical law. It illustrates how semantic and relational patterns can be reflected in vector geometry.

---


---

## 7. How vocabulary and embedding weights are initialized before training

This section makes the preparation pipeline explicit: **the vocabulary/token-to-ID mapping is normally established before the model is trained, while the embedding vectors are trainable parameters that are learned or fine-tuned during training.**

These are two different operations.

### 7.1 First: build a vocabulary

A tokenizer processes the training text and identifies the tokens the model will use. In a simple word-level example, the vocabulary might be:

| Token | Token ID |
|---|---:|
| `<PAD>` | 0 |
| `<UNK>` | 1 |
| `King` | 2 |
| `Queen` | 3 |
| `Man` | 4 |
| `Woman` | 5 |
| `Emperor` | 6 |
| `Clothes` | 7 |
| `has` | 8 |
| `no` | 9 |

The IDs are identifiers, not numerical measurements. For example, ID `8` does not mean that `has` is greater than `King` (ID `2`), and the distance between IDs has no semantic meaning.

In a typical fixed-vocabulary training pipeline:

1. Collect the training text.
2. Apply the chosen tokenizer and normalization rules.
3. Build the vocabulary (or use a predefined tokenizer vocabulary).
4. Assign each token an integer ID.
5. Convert each text sequence into a sequence of token IDs.

In practice, modern language models often use subword tokenizers such as BPE or SentencePiece rather than a separate token for every complete word. The same principle applies: each token in the tokenizer vocabulary has an ID.

**Data-splitting note:** Build or fit a data-dependent vocabulary using the training split only. Validation and test text should be transformed using that already-established vocabulary. This avoids allowing information from evaluation data to influence preprocessing. A pretrained tokenizer may instead come with a vocabulary that was established during its own pretraining process.

### 7.2 Second: create the embedding matrix

Once the vocabulary size is known, the model can create an embedding table.

Suppose:

- Vocabulary size \(V=10\)
- Embedding dimension \(d=3\)

Using the common table-oriented convention, the embedding matrix is:

\[
E\in\mathbb{R}^{V\times d}=\mathbb{R}^{10\times3}
\]

It contains one row per token ID. Each row is that token's embedding vector.

For example, an illustrative initial matrix could look like this:

\[
E=
\begin{bmatrix}
0.02 & -0.11 & 0.07\\
-0.04 & 0.09 & 0.03\\
0.12 & 0.01 & -0.08\\
\vdots & \vdots & \vdots
\end{bmatrix}
\]

These values are only illustrative. In a model trained from scratch, embedding parameters are commonly initialized with small random values (using an initialization scheme appropriate to the model). They are not automatically meaningful at initialization.

The matrix has ten rows because there are ten token IDs, and three columns because each token is represented by a three-dimensional vector.

### 7.3 Third: convert an input token into its embedding

Suppose the input token is `Emperor`.

The tokenizer maps it to:

\[
\text{Emperor}\rightarrow \text{token ID }6
\]

Conceptually, its one-hot representation is:

\[
x_{\text{Emperor}}=
\begin{bmatrix}
0&0&0&0&0&0&1&0&0&0
\end{bmatrix}
\]

With the table-oriented convention \(E\in\mathbb{R}^{V\times d}\), the embedding is:

\[
e_{\text{Emperor}}=x_{\text{Emperor}}E
\]

The one-hot vector selects row 6 of \(E\). The result is a dense vector of dimension 3.

This is the mathematical connection between one-hot encoding and embedding lookup:

- One-hot vector: identifies which vocabulary entry is selected.
- Embedding matrix: stores a trainable vector for each vocabulary entry.
- Matrix multiplication: selects the corresponding row when the one-hot vector is represented as a row vector.

### 7.4 Why did the earlier equation use \(E x\)?

You may see the multiplication written in either direction. The difference is the chosen matrix orientation.

| Convention | Embedding matrix shape | One-hot shape | Lookup equation |
|---|---:|---:|---|
| Table-oriented (used in this section) | \(V\times d\) | \(1\times V\) row vector | \(e=xE\) |
| Column-oriented | \(d\times V\) | \(V\times1\) column vector | \(e=Ex\) |

Both conventions select the same embedding. Always check the matrix dimensions before multiplying. The underlying idea does not change.

### 7.5 What happens in real code?

Frameworks generally do not create a large one-hot vector and multiply it by the full embedding matrix. They use the integer token ID to perform a direct row lookup.

Conceptual PyTorch-style example:

```python
import torch
import torch.nn as nn

vocab_size = 10
embedding_dim = 3

embedding = nn.Embedding(
    num_embeddings=vocab_size,
    embedding_dim=embedding_dim
)

emperor_token_id = torch.tensor([6])

emperor_vector = embedding(emperor_token_id)

print(emperor_vector.shape)  # torch.Size([1, 3])
```

`nn.Embedding(10, 3)` creates a trainable lookup table with ten rows and three values per row. Passing token ID `6` retrieves row 6. The example's initial numbers are not meaningful word representations yet.

### 7.6 When do the embedding values learn?

During training, the embedding matrix is normally part of the model's trainable parameters.

For a next-token prediction example:

```text
Input tokens:  Emperor  has  no
Target token:  Clothes
```

The training flow is:

```text
Raw text
   |
   v
Tokenizer
   |
   v
Token IDs: [6, 8, 9]
   |
   v
Embedding lookup
   |
   v
Dense vectors: [e6, e8, e9]
   |
   v
RNN forward pass
   |
   v
Predicted vocabulary scores (logits)
   |
   v
Loss compared with the target token "Clothes"
   |
   v
Backpropagation Through Time (BPTT)
   |
   v
Optimizer updates trainable parameters
   |
   +--> Embedding matrix
   +--> RNN weights and biases
   +--> Output-layer weights and biases
```

The loss produces gradients. Those gradients can update the embedding rows involved in the computation, as well as the RNN and output-layer parameters. Across many training examples, the embedding vectors are adjusted to help the model perform its objective.

If pretrained embeddings are used, they already contain learned values. Depending on the training setup, they can be frozen (not updated) or fine-tuned (updated during training).

### 7.7 The distinction to remember

| Established before model training | Learned or adjusted during training |
|---|---|
| Tokenizer rules and vocabulary | Embedding vector values (if trainable) |
| Token-to-ID mapping | \(W_{xh}\), \(W_{hh}\), \(W_{hy}\) |
| Vocabulary size \(V\) | Bias parameters |
| Embedding dimension \(d\) is selected as a hyperparameter | The numerical embedding representations |

The embedding table's **shape** is determined by the vocabulary size and embedding dimension. Its **values** are initialized and then learned (unless frozen or supplied as fixed features).

> **Core takeaway:** The vocabulary tells the model *which token ID represents each token*. The embedding matrix tells the model *which trainable vector is associated with each token ID*.

---

## 8. Worked conceptual example: “Emperor has no”

The article's central example is next-word prediction.

**Input context:**

> Emperor has no

**Desired next word:**

> Clothes

Assume the RNN has already been trained. We are examining its forward pass, not training it.

For ease of visualization, imagine high-dimensional vectors as 2D arrows. The 2D arrows are conceptual illustrations; the actual model may use 300-dimensional hidden states.

### Step 1: Process “Emperor”

At the first timestep, the initial hidden state is zero:

\[
h_0=0
\]

The model looks up the embedding \(x_1\) for `Emperor` and calculates:

\[
h_1=\tanh(W_{xh}x_1+W_{hh}h_0+b_h)
\]

The resulting \(h_1\) is the new state.

### Step 2: Process “has”

The model retrieves the embedding \(x_2\) for `has`.

First, the previous state is transformed:

\[
W_{hh}h_1
\]

Then it is combined with the transformed current input:

\[
z_2=W_{xh}x_2+W_{hh}h_1+b_h
\]

Finally:

\[
h_2=\tanh(z_2)
\]

The article uses a 45-degree rotation as a simplified geometric illustration of a possible transformation by \(W_{hh}\). In an actual RNN, \(W_{hh}\) is a learned matrix and can perform much more general transformations than a simple rotation.

### Step 3: Process “no”

The same operation is repeated:

\[
h_3=\tanh(W_{xh}x_3+W_{hh}h_2+b_h)
\]

The state \(h_3\) now reflects the processing of the context `Emperor has no`.

The key idea is that the current word is processed together with the transformed previous state. The model does not process each word in isolation.

---

## 9. How the output layer and Softmax predict a word

After processing the context, the model has a hidden state \(h_3\). The output layer maps it to a score for each vocabulary item.

Suppose:

- Hidden dimension = 300.
- Vocabulary size = 40,000.
- \(h_3\in\mathbb{R}^{300}\).
- \(W_{hy}\in\mathbb{R}^{40000\times300}\).

Then:

\[
o_3=W_{hy}h_3+b_y
\]

The result is a vector of 40,000 logits—one score per vocabulary entry.

### 8.1 Logits are not probabilities

Imagine a tiny vocabulary with these illustrative logits:

\[
z=[3,2,1]
\]

These are raw scores. They can be negative, positive, or larger than 1.

Softmax converts them into probabilities:

\[
\operatorname{softmax}(z)_i=
\frac{e^{z_i}}{\sum_j e^{z_j}}
\]

For the example above:

\[
\operatorname{softmax}([3,2,1])
\approx[0.665,0.245,0.090]
\]

The probabilities sum to approximately 1.

### 8.2 Selecting the next word

A model may choose the highest-probability word (greedy decoding) or sample from the distribution using a decoding strategy.

![Pipeline from words to embeddings, RNN state, logits, and Softmax probabilities.](images/next_word_pipeline.png)

In the article's conceptual example, the output score for `Clothes` is the strongest, so the network predicts:

\[
\boxed{\text{Emperor has no}\rightarrow\text{Clothes}}
\]

### 8.3 Geometric interpretation of the output scores

Each output class has a learned weight vector \(w_i\). The score for class \(i\) is:

\[
o_i=w_i^T h_3+b_i
\]

This is a dot product plus bias. It measures how strongly the hidden state aligns with that class's learned output weights.

The class with the largest logit receives the largest Softmax probability.

**Important clarification:** These output-class weight vectors are not necessarily the same as the input word embeddings. Some language models tie input embedding weights and output weights, but this is an architectural choice, not a requirement of every RNN.

---

## 10. Sequence representations and sentence vectors

The article makes another important observation: the final hidden state can be used as a fixed-size representation of the sequence.

After processing:

> Emperor has no

the state \(h_3\) summarizes the sequence so far.

If the model then processes `clothes`, it calculates:

\[
h_4=\tanh(W_{xh}x_4+W_{hh}h_3+b_h)
\]

Now \(h_4\) is the final state after the complete sequence:

> Emperor has no clothes.

The number of dimensions in \(h_4\) is fixed by the hidden-state size, not by the number of words in the sentence.

This gives a **sequence-to-vector** representation.

### Why can this be useful?

A fixed-size vector can be used by a downstream model for classification or similarity-related tasks. For example, a system could compare sentence vectors using cosine similarity.

However, a basic RNN's final state is not automatically a strong general-purpose semantic embedding. It is a learned representation shaped by the training objective and may struggle to retain information from long sequences.

---

## 11. Stacked RNNs

The article asks why a network might need more than one recurrent hidden layer.

A stacked RNN has multiple recurrent layers. Each layer has its own hidden state and recurrent parameters.

A simplified intuition:

- A lower recurrent layer learns representations from the input sequence.
- A higher recurrent layer processes those representations and can learn more abstract patterns.

This is analogous, at a high level, to the hierarchy of representations learned by deeper neural networks such as CNNs.

A second recurrent layer does not automatically guarantee better sentence representations. It adds capacity and complexity; performance depends on data, architecture, and training.

---

## 12. Three input-output patterns

RNNs can be arranged for different sequence tasks.

![Common RNN input-output patterns: sequence-to-vector, vector-to-sequence, and sequence-to-sequence.](images/rnn_io_patterns.png)

### 11.1 Sequence-to-vector

Many inputs produce one output.

Example: sentiment classification.

- Input: a review containing many words.
- Output: a positive/negative class prediction.

### 11.2 Vector-to-sequence

One input vector produces a sequence.

Example: image captioning.

- Input: a feature vector extracted from an image.
- Output: a sequence of caption words.

### 11.3 Sequence-to-sequence

An input sequence produces an output sequence.

Example: machine translation.

- Input: an English sentence.
- Output: a French sentence.

These are high-level input-output patterns. Practical systems can use encoder-decoder structures and additional mechanisms.

---

## 13. Sentiment analysis with an RNN

Consider two reviews:

**Review A**

> I bought this phone. It is awesome.

**Review B**

> Honda Accords and Toyota Camrys are nice sedans, but hardly the best car on the road.

A keyword-only approach may overreact to words such as `nice`. A sequential model can use context from the full input.

A typical sequence-to-vector sentiment pipeline is:

1. Tokenize the review.
2. Convert tokens into embedding vectors.
3. Feed the vectors to the RNN in order.
4. Take the final hidden state (or another sequence aggregation).
5. Pass it to a classifier.
6. Apply Softmax if probabilities are required.

Illustrative output:

\[
P(\text{positive})=0.12
\]

\[
P(\text{negative})=0.88
\]

The predicted class is negative. These numbers are illustrative, not measured results from the article.

---

## 14. Limitations of vanilla RNNs

A vanilla RNN repeatedly updates its hidden state. As sequences become long, it can become difficult to preserve useful information from early timesteps.

Two important training problems are:

### 13.1 Vanishing gradients

During training, gradients are propagated backward through the sequence using **Backpropagation Through Time (BPTT)**.

Repeated multiplication by derivatives and weight matrices can cause gradients to become extremely small.

When this happens, early timesteps receive a weak learning signal. The model can struggle to learn long-range dependencies.

### 13.2 Exploding gradients

Gradients can also become extremely large during repeated backward propagation. This can cause unstable updates and make training difficult.

Gradient clipping is one practical technique used to limit excessively large gradient norms.

### 13.3 Why LSTM and GRU were introduced

Gated recurrent architectures were developed to improve the handling of information over time.

| Architecture | Core idea |
|---|---|
| Vanilla RNN | Updates a hidden state using current input and previous hidden state |
| LSTM | Uses gates and a cell state to regulate information flow |
| GRU | Uses update and reset gates to control information flow |

The supplied article introduces these architectures as topics beyond its main scope. The table above is a brief contextual preview; the detailed LSTM and GRU equations are not covered in the source article.

---

## 15. Key takeaways

1. **RNNs process sequences:** They handle variable-length sequences by repeating a shared computation across timesteps.
2. **The hidden state is recurrent memory:** It is a learned representation of information accumulated from the sequence so far.
3. **\(W_{xh}\) transforms the current input:** It maps the current input into the hidden-state computation.
4. **\(W_{hh}\) transforms previous memory:** It carries transformed information from the previous timestep.
5. **\(W_{hy}\) produces output scores:** It maps the hidden state into the output space.
6. **Embeddings represent words as dense vectors:** They provide numerical representations that can capture useful relationships learned from data.
7. **Softmax converts logits into probabilities:** It creates a probability distribution over output classes or vocabulary items.
8. **The final hidden state can represent a sequence:** It has a fixed dimension even when sequence length varies.
9. **Vanilla RNNs have limitations:** In particular, vanishing and exploding gradients can make long-range dependencies difficult to learn.

### The complete mental model

For each timestep:

1. Receive the current input vector \(x_t\).
2. Transform it using \(W_{xh}\).
3. Transform the previous hidden state using \(W_{hh}\).
4. Add the transformed vectors and bias.
5. Apply the activation function to obtain \(h_t\).
6. Optionally map \(h_t\) through \(W_{hy}\) to produce output logits.
7. Apply Softmax when a probability distribution is needed.

The central equation is:

\[
\boxed{h_t=\tanh(W_{xh}x_t+W_{hh}h_{t-1}+b_h)}
\]

---

## 16. Knowledge check

Try answering these without looking back.

1. What is the purpose of the hidden state \(h_t\)?
2. Why does the first timestep commonly use \(h_0=0\)?
3. What is the difference between \(W_{xh}\) and \(W_{hh}\)?
4. Why is the same recurrent cell reused at every timestep?
5. What does an embedding layer do with a word index?
6. Why is a one-hot vector not itself a semantic embedding?
7. What is the difference between logits and Softmax probabilities?
8. How can the final hidden state represent a variable-length sequence?
9. What causes vanishing gradients in a vanilla RNN?
10. Why were LSTMs and GRUs developed?
11. What is decided when the vocabulary is built, and what is learned when embeddings are trained?
12. If \(V=10{,}000\) and \(d=300\), what is the shape of a table-oriented embedding matrix?

### Answers for self-check

1. It represents learned information accumulated from the sequence so far.
2. There is no preceding sequence state; zero is a common initialization.
3. \(W_{xh}\) transforms the current input; \(W_{hh}\) transforms the previous hidden state.
4. Parameter sharing lets the model apply the same learned transition at every timestep.
5. It retrieves the learned dense vector associated with that vocabulary index.
6. A one-hot vector identifies a category but does not encode semantic relationships by itself.
7. Logits are raw scores; Softmax converts them into normalized probabilities.
8. The state dimension is fixed even though the number of update steps can vary.
9. Repeated backward propagation through time can shrink gradients.
10. They introduce gates and improved state mechanisms to help manage information over time.
11. The vocabulary and token-to-ID mapping are established; trainable embedding vector values are learned or fine-tuned during training.
12. \(10{,}000\times300\), because there is one row per token and one column per embedding dimension.

---

## 17. Glossary

| Term | Meaning |
|---|---|
| Sequence | Ordered data, such as words in a sentence |
| Timestep | One position in the sequence-processing process |
| Hidden state | The RNN's learned recurrent representation |
| Recurrent connection | Connection that carries the previous state into the next computation |
| Weight matrix | Trainable parameters that transform vectors |
| One-hot encoding | Sparse vector with one active position |
| Embedding | Dense learned vector representation |
| Logit | Raw output score before Softmax |
| Softmax | Function that converts scores into probabilities |
| BPTT | Backpropagation Through Time; training procedure for recurrent networks |
| Vanishing gradient | Gradients become very small during training |
| Exploding gradient | Gradients become excessively large during training |
| LSTM | Long Short-Term Memory network |
| GRU | Gated Recurrent Unit |

---

## Suggested next lesson

**Implement a tiny vanilla RNN numerically.** Use small matrices and a short input sequence to calculate \(h_1\), \(h_2\), and \(h_3\) by hand. Then implement the same forward pass in NumPy. This makes the recurrent update concrete before moving to BPTT, LSTM, and GRU.
